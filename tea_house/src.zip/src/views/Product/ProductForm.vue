<template>
    <div>
        <span>6</span>
    </div>
</template>
<script>
    export default {
        name: 'ProductForm',
        data() {
            return {

            }
        },
        methods: {

        }
    }
</script>